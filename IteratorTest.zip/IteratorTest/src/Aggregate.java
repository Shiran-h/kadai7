
interface Aggregate {
	public Iterator createIterator();

}
